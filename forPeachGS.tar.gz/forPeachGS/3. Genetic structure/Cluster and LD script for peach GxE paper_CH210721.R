################################################################################
#
# Complete script for Cluster and LD plot for peach GxE paper
#
################################################################################

################################################################################
# 1. Preliminary ####
###############################################################################

    ############################################################
    # 1.2. Load libraries ####
    ############################################################

    library(lattice)
    library(Matrix)
    library(dplyr)
    library(plyr)
    library(ape)
    library(pvclust)
    library(ggdendro)
    library(dendextend)
    library(RColorBrewer)
    library(LDlinkR)
    library(openair)
    library(ggplot2)
    library(ggpubr)
    library(tidyr)
    library(snpStats) #CHNOTE: Note available for 3.6.2
    library(car)

###############################################################################
# 2. Load curated data ####
###############################################################################

load("../2. Curation/Curation.RData")
    
###############################################################################
# 4.Fst in R package
###############################################################################
    
    ############################################################
    # 4.1. Mel
    ############################################################
    
    wsdata_GID <- wsdata_prep
    wsdata_GID$GID <- rownames(wsdata)
    
    GID_L_wsdata_tmp <- merge(GID_L_tmp,wsdata_GID)
    L_wsdata <- GID_L_wsdata_tmp[,2:ncol(GID_L_wsdata_tmp)]
    rownames(L_wsdata) <- GID_L_wsdata$GID

    library(hierfstat)
    
    Fst <- pairwise.WCfst(L_wsdata,diploid = T)   
    
    ###########################################################################
    # 2.3.3.4.Fst in R package
    ######################
    
               library(StAMPP)
                    
              uGID_L_tmp <- GID_L_tmp[!duplicated(GID_L_tmp$GID),]
              gsdata_prep_com <- merge(gsdata_prep_mod, uGID_L_tmp, by="GID")
              
              ### Prepare input file
              M <- gsdata_prep_mod
              M[M==0] = "AA"
              M[M==1] = "AB"
              M[M==2] = "BB"
              
              ### rename L to pop
              M <- data.frame(GID = row.names(M), M)
              Fst_in_tmp <- merge(M, uGID_L_tmp, by="GID")
              Fst_in_tmp$format <- "BiA"
              Fst_in_tmp$ploidy <- "2"
              ### rename L to pop
              Fst_in_tmp <- rename(Fst_in_tmp, c("L"="pop"))
              
              ### re order the column in bring GID, pop, ploidy, and format to first
              
              Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .before = GID)
              Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .after = GID)
              Fst_in_tmp <- as.data.frame(Fst_in_tmp)
              
              Fst_in_mod <- Fst_in_tmp
              
              Fst_in <- stamppConvert(Fst_in_mod, type="r")
              
              ###  global pairwise Fst
              
              Fst_output <- stamppFst(Fst_in, nboots=200, percent=95, nclusters = 4)
              Fst_output$Fsts
    
###############################################################################
# 5. LD
###############################################################################

       #######################################
        # 2.3.3. LD plot based on gsdata and qsdata
        #######################################     

            #######################################
            # 2.3.3.1. Prepare inpute file for LD plot for qsdata 
            ####################################### 
            
            All_pop_ld <- read.table("../3. Genetic structure/LD PLINK inputFile/All_population_2.ld", header = TRUE)
            F_G_pop_ld <- read.table("../3. Genetic structure/LD PLINK inputFile/FG_population_2.ld", header = TRUE)
            K_pop_ld <- read.table("../3. Genetic structure/LD PLINK inputFile/K_population_2.ld", header = TRUE)
            S_pop_ld <- read.table("../3. Genetic structure/LD PLINK inputFile/S_population_2.ld", header = TRUE)
            
            #######################################
            # 2.3.3.2. Generate LD plot
            ####################################### 
            
                  ######################
                  # 2.3.3.2.1. LD plot Based on all population
                  ######################
                  
                  All_pop_ld$distance <- (All_pop_ld$BP_B - All_pop_ld$BP_A) 
                  
                  All_pop <- binData(All_pop_ld, bin = "distance", uncer = "R2", interval = 1000)
            
                  geom_line(color='red',data = All_pop, aes(x=~distance, y=~mean))
                  allLD <- ggplot(All_pop, aes(x=distance, y=mean)) +
                    geom_point() +  scale_x_continuous(breaks=c(0,25*10^4,50*10^4,75*10^4,100*10^4),labels=c("0", "250","500","750","1000"))+
                    theme_bw() +
                    geom_point(color='black',data = All_pop, aes(x=distance, y=mean)) + 
                    geom_smooth(method = "loess", se = FALSE, color="red", lwd=1)+ 
                    #ggtitle ("Decay of LD") +
                    theme(plot.title = element_text(hjust = 0.5)) +
                   # xlab("Distance between SNPs (Kb)") +
                    ylab("all_LD") +
                    theme(axis.text.x = element_text(color = "black", size = 14),
                          axis.text.y = element_text(color = "black", size = 14),  
                          axis.title.x = element_text(color = "black", size = 14),
                          axis.title.y = element_text(color = "black", size = 14))
                  
                  ######################
                  # 2.3.3.2.2. LD plot based on F + G population
                  ######################
       
                    F_G_pop_ld$distance <- (F_G_pop_ld$BP_B - F_G_pop_ld$BP_A) 
                    
                    F_G_pop <- binData(F_G_pop_ld, bin = "distance", uncer = "R2", interval = 1000)
                    
                    geom_line(color='red',data = F_G_pop, aes(x=~distance, y=~mean))
                    FG_LD <- ggplot(F_G_pop, aes(x=distance, y=mean)) +
                      geom_point() +  scale_x_continuous(breaks=c(0,25*10^4,50*10^4,75*10^4,100*10^4),labels=c("0", "250","500","750","1000"))+
                      theme_bw() +
                      geom_point(color='black',data = F_G_pop, aes(x=distance, y=mean)) + 
                      geom_smooth(method = "loess", se = FALSE, color="red", lwd=1)+ 
                      #ggtitle ("Decay of LD") +
                      theme(plot.title = element_text(hjust = 0.5)) +
                     # xlab("Distance between SNPs (Kb)") +
                      ylab("FG_LD") +
                      theme(axis.text.x = element_text(color = "black", size = 14),
                            axis.text.y = element_text(color = "black", size = 14),  
                            axis.title.x = element_text(color = "black", size = 14),
                            axis.title.y = element_text(color = "black", size = 14))
            
                  ######################
                  # 2.3.3.2.3. LD plot based on K population
                  ######################
      
                  K_pop_ld$distance <- (K_pop_ld$BP_B - K_pop_ld$BP_A) 
                  
                  K_pop <- binData(K_pop_ld, bin = "distance", uncer = "R2", interval = 1000)
                  
                  geom_line(color='red',data = K_pop, aes(x=~distance, y=~mean))
                  K_LD <- ggplot(K_pop, aes(x=distance, y=mean)) +
                    geom_point() +  scale_x_continuous(breaks=c(0,25*10^4,50*10^4,75*10^4,100*10^4),labels=c("0", "250","500","750","1000"))+
                    theme_bw() +
                    geom_point(color='black',data = K_pop, aes(x=distance, y=mean)) + 
                    geom_smooth(method = "loess", se = FALSE, color="red", lwd=1)+ 
                    #ggtitle ("Decay of LD") +
                    theme(plot.title = element_text(hjust = 0.5)) +
                    #xlab("Distance between SNPs (Kb)") +
                    ylab("K_LD") +
                    theme(axis.text.x = element_text(color = "black", size = 14),
                          axis.text.y = element_text(color = "black", size = 14),  
                          axis.title.x = element_text(color = "black", size = 14),
                          axis.title.y = element_text(color = "black", size = 14))
            
                  ######################
                  # 2.3.3.2.4. LD plot based on S population
                  ######################
                  
                  S_pop_ld$distance <- (S_pop_ld$BP_B - S_pop_ld$BP_A) 
                  
                  S_pop <- binData(S_pop_ld, bin = "distance", uncer = "R2", interval = 1000)
                  geom_line(color='red',data = S_pop, aes(x=~distance, y=~mean))
                  S_LD <- ggplot(S_pop, aes(x=distance, y=mean)) +
                    geom_point() +  scale_x_continuous(breaks=c(0,25*10^4,50*10^4,75*10^4,100*10^4),labels=c("0", "250","500","750","1000"))+
                    theme_bw() +
                    geom_point(color='black',data = S_pop, aes(x=distance, y=mean)) + 
                    geom_smooth(method = "loess", se = FALSE, color="red", lwd=1)+ 
                    #ggtitle ("Decay of LD") +
                    theme(plot.title = element_text(hjust = 0.5)) +
                    xlab("Distance between SNPs (Kb)") +
                    ylab("S_LD") +
                    theme(axis.text.x = element_text(color = "black", size = 14),
                          axis.text.y = element_text(color = "black", size = 14),  
                          axis.title.x = element_text(color = "black", size = 14),
                          axis.title.y = element_text(color = "black", size = 14))
                  
                  ######################
                  # 2.3.3.2.6.Combine all LD plots for population
                  ######################

                  ggarrange(allLD, FG_LD, K_LD, S_LD + font("x.text", size = 10),
                            ncol = 1, nrow = 4)
                           
              ######################
              # 2.3.3.1.Scatter plot between FG_LD and S_LD population
              ######################
              
              #### Scatter plot between FG_LD and S_LD population, and vs K_pop
              F_G_pop_ld_mod <- F_G_pop_ld
              S_pop_ld_mod <- S_pop_ld
              K_pop_ld_mod <- K_pop_ld
              
              ### FG pop
              F_G_pop_ld_mod$distance <- (F_G_pop_ld_mod$BP_B - F_G_pop_ld_mod$BP_A)
              F_G_pop_ld_mod$chdistance <- paste(F_G_pop_ld_mod$CHR_A, F_G_pop_ld_mod$distance, sep="_")
              F_G_pop_ld_mod_tmp <- F_G_pop_ld_mod[,c("chdistance", "R2")]
              colnames(F_G_pop_ld_mod_tmp)[2] <- "FG_R2"
              
              ### S pop
              S_pop_ld_mod$distance <- (S_pop_ld_mod$BP_B - S_pop_ld_mod$BP_A)
              S_pop_ld_mod$chdistance <- paste(S_pop_ld_mod$CHR_A, S_pop_ld_mod$distance, sep="_")
              S_pop_ld_mod_tmp <- S_pop_ld_mod[,c("chdistance", "R2")]
              colnames(S_pop_ld_mod_tmp)[2] <- "S_R2"
              
              ### K pop
              K_pop_ld_mod$distance <- (K_pop_ld_mod$BP_B - K_pop_ld_mod$BP_A)
              K_pop_ld_mod$chdistance <- paste(K_pop_ld_mod$CHR_A, K_pop_ld_mod$distance, sep="_")
              K_pop_ld_mod_tmp <- K_pop_ld_mod[,c("chdistance", "R2")]
              colnames(K_pop_ld_mod_tmp)[2] <- "K_R2"
              
              ### Combine the two pop LDs
              
              All_pop_ld_comb <- merge(merge( F_G_pop_ld_mod_tmp, S_pop_ld_mod_tmp, by = "chdistance", all = TRUE ), K_pop_ld_mod_tmp, by = "chdistance", all = TRUE )

              ### Split the chrDistance
              All_pop_ld_comb_spl <- separate(data = All_pop_ld_comb, col = chdistance, into = c("chr", "distance"), sep = "_")
   
              All_pop_ld_comb_spl$distance <- as.numeric(All_pop_ld_comb_spl$distance)
              
              ### remove a row contatining NA
              All_pop_ld_comb_spl_NA0 <- All_pop_ld_comb_spl[complete.cases(All_pop_ld_comb_spl), ]
  
              # plot(FG_S_ld_spl$FG_R2, FG_S_ld_spl$S_R2, pch=16, col="blue", xlab = "R2_FG_pop", ylab="R2_S_pop")
              
              ### Bin r2 based on the distance interval
              binAll_pop_ld_comb_spl <- binData(All_pop_ld_comb_spl_NA0, bin = "distance", uncer = "FG_R2",interval = 100)
              
              par(mfrow=c(2,2))
              plot(binAll_pop_ld_comb_spl$FG_R2, binAll_pop_ld_comb_spl$S_R2, pch=16, cex=0.5, col="black", xlab = "R2_FG_pop", ylab="R2_S_pop")
              plot(binAll_pop_ld_comb_spl$FG_R2, binAll_pop_ld_comb_spl$K_R2, pch=16, cex=0.5, col="black", xlab = "R2_FG_pop", ylab="R2_K_pop")
              plot(binAll_pop_ld_comb_spl$K_R2, binAll_pop_ld_comb_spl$S_R2, pch=16, cex=0.5, col="black", xlab = "R2_K_pop", ylab="R2_S_pop")
              
              ### Scatter plot in a quadrant
              pairs(~FG_R2+S_R2+K_R2,data=binAll_pop_ld_comb_spl,lower.panel = NULL)
        
              ### LD plot FG and S population
              binAll_pop_ld_comb_spl <- binData(All_pop_ld_comb_spl, bin = "distance", uncer = "FG_R2", interval = 10000)
              plot(binAll_pop_ld_comb_spl$distance,binAll_pop_ld_comb_spl$FG_R2,type="l", 
              col="red",ylim=c(0,max(binAll_pop_ld_comb_spl$K_R2,binAll_pop_ld_comb_spl$FG_R2)), 
              lwd=2,xlab="Distance between SNPs (bp)", ylab="Average Linkage Disequilibrium (R^2)") 
              points(binAll_pop_ld_comb_spl$distance,binAll_pop_ld_comb_spl$S_R2,type="l",col="green",lwd=2) 
              #legend("topright",0.15,c("FG population","S population"),lwd=c(2,2),col=c("red","blue"))
              
              points(binAll_pop_ld_comb_spl$distance,binAll_pop_ld_comb_spl$K_R2,type="l",col="blue",lwd=2) 
              legend("topright",0.15,c("FG population", "S population","K population"),lwd=c(3,3),col=c("red","green","blue"))
              
              ### LD decay
              
              plot(binAll_pop_ld_comb_spl$distance,binAll_pop_ld_comb_spl$FG_R2,col = 'black', xlab = "Distance (bp)", ylab = "r2", main = "" ,xlim=c(1e2,1e6))
              decay2=binAll_pop_ld_comb_spl[binAll_pop_ld_comb_spl$distance>=1e2 & binAll_pop_ld_comb_spl$distance<=1e6,]
              lo <- loess.smooth(decay2$distance, decay2$FG_R2,span =1/10, degree =2,family = "gaussian", zero.line = F, evaluation = 10)
              points(lo,col = 'red', type = "l",lwd = 2) 
               
              decay3=binAll_pop_ld_comb_spl[binAll_pop_ld_comb_spl$distance>=1e2 & binAll_pop_ld_comb_spl$distance<=3e6,]
              lo <- loess.smooth(decay3$distance, decay3$S_R2,span =1/10, degree =2,family = "gaussian", zero.line = F, evaluation = 10)
              points(lo,col = 'green', type = "l",lwd = 2) 
              
              decay4=binAll_pop_ld_comb_spl[binAll_pop_ld_comb_spl$distance>=1e2 & binAll_pop_ld_comb_spl$distance<=3e6,]
              lo <- loess.smooth(decay4$distance, decay4$K_R2,span =1/10, degree =2,family = "gaussian", zero.line = F, evaluation = 10)
              points(lo,col = 'blue', type = "l",lwd = 2) 
              
              legend("topright",0.15,c("FG population", "S population","K population"),lwd=c(3,3),col=c("red","green","blue"))

              
              ######################
              # 2.3.3.2.LD using snpStats R package
              ######################
              
              ### LD for all population
              ### Convert genotyping coding 0,1,2 to 1,2,3 because 0 is for missing in the package
        
              ### Convert gsdata_ld to snpMatrix object
              gsdata_ld_mat <- new("SnpMatrix", t(t(gsdata_prep))+1)
              
              ldAll <- ld(gsdata_ld_mat, depth = 4498, stats = "R.squared")
              
              ## plot LD for AllPop
              cols=colorRampPalette(c("yellow", "red")) (10)
              image(ldAll [1:1000, 1:1000], lwd=0, cuts=9,col.regions=cols, colorkey=TRUE)
              
              ### Subset population
              ### gsdataFile
              gsdata_prep_mod <- gsdata_prep
              gsdata_prep_mod <- data.frame(GID = row.names(gsdata_prep_mod), gsdata_prep_mod)
      
              ### locationFile        
              uGID_L_tmp <- GID_L_tmp[!duplicated(GID_L_tmp$GID),]
              gsdata_prep_com <- merge(gsdata_prep_mod, uGID_L_tmp, by="GID")
              
              ### Subset population
              FG_sdata <- gsdata_prep_com[gsdata_prep_com$L%in%c("F", "G"),]
              S_sdata <- gsdata_prep_com[gsdata_prep_com$L%in%c("S"),]
              
              ### Prepare inputFile for snpStats package
              ### FG pop
              FG_sdata_mod <- FG_sdata
              
              FG_sdata_mod$GID <- NULL
              FG_sdata_mod$L <- NULL
              
              ### S pop
              S_sdata_mod <- S_sdata
              S_sdata_mod$GID <- NULL
              S_sdata_mod$L <- NULL
              
              ### Convert S_sdata to snpMatrix object
              FG_ld_mat <- new("SnpMatrix", t(t(FG_sdata_mod))+1)
              S_ld_mat <- new("SnpMatrix", t(t(S_sdata_mod))+1)
              
              FG_ld <- ld(FG_ld_mat, depth = 4498, stats = "R.squared")
              S_ld <- ld(S_ld_mat, depth = 4498, stats = "R.squared")
              
              ### plot LD for S Pop
              cols=colorRampPalette(c("yellow", "red")) (10)
              image(FG_ld [1:1000, 1:1000], lwd=0, cuts=9,col.regions=cols, colorkey=TRUE)
              image(S_ld [1:1000, 1:1000], lwd=0, cuts=9,col.regions=cols, colorkey=TRUE)
                
              ######################
              # 2.3.3.3.Correlation of phased LD between population
              ######################
              
              All_pop_ld_comb_spl_NA0_ord <- All_pop_ld_comb_spl_NA0[with(All_pop_ld_comb_spl_NA0, order(distance)),]
              All_pop_ld_comb_spl_NA0_ord$dis_bin <- trunc(All_pop_ld_comb_spl_NA0_ord$distance/1000)*1000
              gp = group_by(All_pop_ld_comb_spl_NA0_ord, dis_bin)
              
              FG_S_corr <- as.data.frame(dplyr::summarize(gp, cor(FG_R2, S_R2)))
              colnames(FG_S_corr)[2] <- "FGS_r2"
              
              FG_K_corr <- as.data.frame(dplyr::summarize(gp, cor(FG_R2, K_R2)))
              colnames(FG_K_corr)[2] <- "FGK_r2"
              
              KS_corr <- as.data.frame(dplyr::summarize(gp, cor(K_R2, S_R2)))
              colnames(KS_corr)[2] <- "KS_r2"   
              
              
              plot(FG_S_corr$dis_bin,FG_S_corr$FGS_r2,col = 'black', xlab = "Distance (bp)", ylab = "Correlation of LD phase", main = "" ,xlim=c(1e2,1e6))
              decay2=FG_S_corr[FG_S_corr$dis_bin>=1e2 & FG_S_corr$dis_bin<=1e6,]
              lo <- loess.smooth(decay2$dis_bin, decay2$FGS_r2,span =1/10, degree =2,family = "gaussian", zero.line = F, evaluation = 10)
              points(lo,col = 'red', type = "l",lwd = 2) 
              
              decay3=FG_K_corr[FG_S_corr$dis_bin>=1e2 & FG_K_corr$dis_bin<=1e6,]
              lo <- loess.smooth(decay3$dis_bin, decay3$FGK_r2,span =1/10, degree =2,family = "gaussian", zero.line = F, evaluation = 10)
              points(lo,col = 'orange', type = "l",lwd = 2) 
              
              decay4=KS_corr[KS_corr$dis_bin>=1e2 & KS_corr$dis_bin<=1e6,]
              lo <- loess.smooth(decay4$dis_bin, decay4$KS_r2,span =1/10, degree =2,family = "gaussian", zero.line = F, evaluation = 10)
              points(lo,col = 'green', type = "l",lwd = 2) 
              
              legend("bottomleft",0.15,c("r(FG vs S population", "r(FG vs K population)","r(K vs S population)"),lwd=c(3,3),col=c("red","orange","green"))
              
                  
    
    

###############################################################################
# 3. Clustering of entries and plotting by populations ####
###############################################################################

    ############################################################
    # 3.1. Cluster plot of whole genome SNPs (wsdata) ####
    ############################################################
            
    wsdata_GID_mat <- dist(wsdata_prep,method ="euclidean")
    wsdend <- as.dendrogram(hclust(wsdata_GID_mat), method= "wards.D2")
        
    ### GID as in dend order
    GID_wsdend <- as.data.frame(labels(wsdend))
    GID_wsdend$index <- rownames(GID_wsdend)
    colnames(GID_wsdend) [1] <- "GID"
        
    ### Extract the GID and Location field from the pdata
    GID_L_tmp <- unique(pdata_prep[,c("GID","L")])
       
    uLoc_all <- unique(GID_L_tmp$L)
    uLoc_all <- sort(factor(uLoc_all), decreasing=TRUE)
         
    n_Loc_all <- length(unique(uLoc_all))
    cols_4 = c("black", "red", "green", "blue")
    #cols_4 = c("yellow", "blue", "cardinal", "orange")
         
    GID_L_tmp_mod <- table(GID_L_tmp$GID, GID_L_tmp$L)
    GID_L_tmp_mod_table <- as.data.frame.matrix(GID_L_tmp_mod) 
        
    GID_L_tmp_mod_table$GID <- rownames(GID_L_tmp_mod_table)
        
    ### Combine and index for the order
    GID_L_tmp_mod_com <- merge(GID_L_tmp_mod_table,GID_wsdend, by="GID")
    GID_L_tmp_mod_com$index <- as.numeric(GID_L_tmp_mod_com$index)
    GID_L_tmp_mod_sort <- GID_L_tmp_mod_com[order(GID_L_tmp_mod_com$index),]
    GID_L_tmp_mod_sort$index <- NULL
    
    ###
    uGID_in <-  GID_L_tmp_mod_sort[,2:ncol(GID_L_tmp_mod_sort)]
    rownames(uGID_in) <-  GID_L_tmp_mod_sort[,1]
       
    uGID_in$F<-ifelse(uGID_in$F=='1', 1,0)
    uGID_in$G<-ifelse(uGID_in$G=='1', 2,0)
    uGID_in$K<-ifelse(uGID_in$K=='1', 3,0)
    uGID_in$S<-ifelse(uGID_in$S=='1', 4,0)
              
    par(mar = c(4,1,1,12))
    plot(wsdend, horiz = TRUE)
    labels_colors(wsdend) <- "white"
    colored_bars(uGID_in[,c(4, 3, 2, 1)], wsdend, sort_by_labels_order=FALSE, rowLabels=uLoc_all, horiz = TRUE)
    legend("topleft", legend = levels(uLoc_all), fill = cols_4)
                
    ############################################################
    # 3.2. Cluster plot of qtl SNPs (qsdata) ####
    ############################################################
            
    qsdata_GID_mat <- dist(qsdata,method ="euclidean")
    qsdend <- as.dendrogram(hclust(qsdata_GID_mat), method= "wards.D2")
        
    ### QID as in dend order
    QID_qsdend <- as.data.frame(labels(qsdend))
    QID_qsdend$index <- rownames(QID_qsdend)
    colnames(QID_qsdend) [1] <- "QID"
        
    ### Extract the QID and Location field from the pdata
    QID_L_tmp <- unique(pdata_prep[,c("QID","L")])
       
    QuLoc_all <- unique(QID_L_tmp$L)
    QuLoc_all <- sort(factor(QuLoc_all), decreasing=TRUE)
         
    n_QLoc_all <- length(unique(QuLoc_all))
    cols_4 = c("black", "red", "green", "blue")
    #cols_4 = c("yellow", "blue", "cardinal", "orange")
         
    QID_L_tmp_mod <- table(QID_L_tmp$QID, QID_L_tmp$L)
    QID_L_tmp_mod_table <- as.data.frame.matrix(QID_L_tmp_mod) 
        
    QID_L_tmp_mod_table$QID <- rownames(QID_L_tmp_mod_table)
        
    ### Combine and index for the order
    QID_L_tmp_mod_com <- merge(QID_L_tmp_mod_table,QID_qsdend, by="QID")
    QID_L_tmp_mod_com$index <- as.numeric(QID_L_tmp_mod_com$index)
    QID_L_tmp_mod_sort <- QID_L_tmp_mod_com[order(QID_L_tmp_mod_com$index),]
    QID_L_tmp_mod_sort$index <- NULL
    
    ###
    uQID_in <-  QID_L_tmp_mod_sort[,2:ncol(QID_L_tmp_mod_sort)]
    rownames(uQID_in) <-  QID_L_tmp_mod_sort[,1]
       
    uQID_in$F<-ifelse(uQID_in$F=='1', 1,0)
    uQID_in$G<-ifelse(uQID_in$G=='1', 2,0)
    uQID_in$K<-ifelse(uQID_in$K=='1', 3,0)
    uQID_in$S<-ifelse(uQID_in$S=='1', 4,0)
              
    par(mar = c(4,1,1,12))
    plot(qsdend, horiz = TRUE)
    labels_colors(qsdend) <- "white"
    colored_bars(uQID_in[,c(4, 3, 2, 1)], qsdend, sort_by_labels_order=FALSE, rowLabels=QuLoc_all, horiz = TRUE)
    #legend("topleft", legend = levels(uLoc_all), fill = cols_4)
                

    
    
    test <- wc(L_wsdata)
# read input data table - column 1 = cluster1-4 
#sdata <- read.table("WCfst_input4.txt", header = TRUE)

## Estimate pairwise FSTs according to Weir and Cockerham (1984) between clusters


    
    
    
# use data table for Fst matrix
WCfst <- pairwise.WCfst(wsdata_prep,diploid=TRUE)

# export data table with matrix of Fst
write.table(WCfst,file = "WCfst_output4.txt", sep = "\t")
WCfst
    
    
    
    
    
library(StAMPP)
      
wsdata_prep_mod <- wsdata
    
uGID_L_tmp <- GID_L_tmp[!duplicated(GID_L_tmp$GID),]
wsdata_prep_com <- merge(wsdata_prep_mod, uGID_L_tmp, by="GID")

### Prepare input file
M <- gsdata_prep_mod
M[M==0] = "AA"
M[M==1] = "AB"
M[M==2] = "BB"

### rename L to pop
M <- data.frame(GID = row.names(M), M)
Fst_in_tmp <- merge(M, uGID_L_tmp, by="GID")
Fst_in_tmp$format <- "BiA"
Fst_in_tmp$ploidy <- "2"

### rename L to pop
Fst_in_tmp <- rename(Fst_in_tmp, c("L"="pop"))

### re order the column in bring GID, pop, ploidy, and format to first

Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .before = GID)
Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .after = GID)
Fst_in_tmp <- as.data.frame(Fst_in_tmp)

Fst_in_mod <- Fst_in_tmp

Fst_in <- stamppConvert(Fst_in_mod, type="r")

###  global pairwise Fst

Fst_output <- stamppFst(Fst_in, nboots=200, percent=95, nclusters = 4)
Fst_output$Fsts            

################################################################################################### 
##### Old script
###################################################################################################
# 2. Prepare data
#################################################################################

    # ############################################################
    # # 2.1. Read in data
    # ############################################################
    # 
    #     ########################################
    #     # 2.1.1. Phenotypic data
    #     ########################################
    #     
    #     pdata_in <- read.csv("../0. Data/pdata_final.csv", stringsAsFactors = F)
# 
        # ########################################
        # # 2.1.2. Genetic data
        # ########################################
        # 
        #     ####################
        #     # 2.1.2.1. SNP data
        #     ####################
        # 
        #        ##########
        #         # 2.1.2.1.1. GW sdata
        #         ##########
        # 
        #         gsdata_in <- read.csv("../0. Data/sdata_final_sommer.csv", stringsAsFactors = F)
        #         colnames(gsdata_in)[1] <- "GID"
        #         ncol(gsdata_in)
        #         
        #         ##########
        #         # 2.1.2.1.2 QTL sdata
        #         ##########
        #         
        #         qsdata_in_temp <- read.csv("../0. Data/sdata_QTL_sommer.csv", stringsAsFactors = F)
        #         qs_SID <- colnames(qsdata_in_temp[,c(2:ncol(qsdata_in_temp))])
        #         
        #         qsdata_in <- gsdata_in[,colnames(gsdata_in)%in%c('GID',qs_SID)]
        #         
        #     ####################
        #     # 2.1.2.2. Genetic map
        #     ####################
        #     
        #     gmap_in <- read.csv("../0. Data/map_sdata.csv", stringsAsFactors = F)
        #     names(gmap_in)[1] <- "sid_ID"
        #     
        #     ##### map for QYL region
        #     qmap_in <- read.csv("../0. Data/map_QTL.csv", stringsAsFactors = F)
        #     names(qmap_in)[1] <- "sid_ID"
            
    # ############################################################
    # # 2.2. Prepare pdata
    # ############################################################
    #         
    #     #########################################
    #     # 2.2.1. K and Y select
    #     #########################################
    #     
    #     #pdata_Kselect <- pdata_in[pdata_in$trait.units == "TSS.Brix",]
    #     #pdata_KYselect <- pdata_Kselect
    #     
    #     #nrow(pdata_KYselect)
    #     
    #     #unique(pdata_KYselect$location)
    #     
    #     #pdata_K <- pdata_KYselect[pdata_KYselect$location == 'Arkansas.US',]
    #     #nrow(pdata_K)
    #     #table(pdata_K$E.unit,pdata_K$year_assessment)
    #     #length(unique(pdata_K$E.unit))
    #     
    #     ##########################################
    #     # 2.2.2. GID list
    #     ##########################################
    #      
    #     GID_in_psdata <- unique(pdata_KYselect$GID[pdata_KYselect$GID%in%gsdata_in$GID])
    #     length(unique(pdata_in$GID))
    #     length(GID_in_psdata)
    #     
    #     pdata_select <- pdata_KYselect[pdata_KYselect$GID%in%GID_in_psdata,]
    #     length(unique(pdata_select$GID))
    #     
    #     ##########################################
    #     # 2.2.3. Create reduced field names
    #     ##########################################
    #     
    #     pdata_newf <- pdata_select
    #     
    #     pdata_newf$L <- pdata_newf[,"location"]
    #     
    #     ##### Modify L levels
    #     pdata_newf$L[pdata_newf$location == "Arkansas.US"] <- "K"
    #     pdata_newf$L[pdata_newf$location == "South_Carolina.US"] <- "S"
    #     pdata_newf$L[pdata_newf$location == "Texas.US"] <- "G"
    #     pdata_newf$L[pdata_newf$location == "California.US"] <- "F"
    # 
    #     #######################
    #     # 2.2.4. Modify data
    #     #######################
    #     
    #     pdata_mod <- pdata_newf
    #     
    #     #########################
    #     # 2.2.5. Create pdata_prep
    #     #########################
    #         
    #     pdata_prep_new <- pdata_mod
    #     nrow(pdata_prep)    
        
    # ############################################################
    # # 2.3. Select and modify sdata
    # ############################################################
    #      
    #     #######################################
    #     # 2.3.1. gsdata
    #     #######################################
    #     
    #         ####################
    #         # 2.3.1.1. Prepare gsdata
    #         ####################
    #      
    #         gsdata_select <- gsdata_in[gsdata_in$GID%in%GID_in_psdata,2:ncol(gsdata_in),]
    #         rownames(gsdata_select) <- gsdata_in$GID
    #         
    #         gsdata_mod <- gsdata_select+1
    #         
    #         gsdata_prep <- gsdata_mod
     

        
###############################################################################
# 2.3.2. Clustering of entries and plotting by populations ####
###############################################################################

    ############################################################
    # 2.3.2. Cluster plot based on gsdata and qsdata ####
    ############################################################
            
        ########################################
        # 2.3.2.1. Cluster plot for all population ####
        ########################################
   
            ####################
            # 2.3.2.1.1. plot ####
            ####################
                
            gsdata_GID_mat <- dist(gsdata_prep,method ="euclidean")
            gdend <- as.dendrogram(hclust(gsdata_GID_mat), method= "wards.D2")
                
            ### GID as in dend order
            GID_gdend <- as.data.frame(labels(gdend))
            GID_gdend$index <- rownames(GID_gdend)
            colnames(GID_gdend) [1] <- "GID"
                
            ### Extract the GID and Location field from the pdata
            GID_L_tmp <- unique(apdata_513[,c("GID","L")])
               
                uLoc_all <- unique(GID_L_tmp$L)
                uLoc_all <- sort(factor(uLoc_all), decreasing=TRUE)
                 
                n_Loc_all <- length(unique(uLoc_all))
                cols_4 = c("black", "red", "green", "blue")
                 
                GID_L_tmp_mod <- table(GID_L_tmp$GID, GID_L_tmp$L)
                GID_L_tmp_mod_table <- as.data.frame.matrix(GID_L_tmp_mod) 
                
                GID_L_tmp_mod_table$GID <- rownames(GID_L_tmp_mod_table)
                
                ### Combine and index for the order
                GID_L_tmp_mod_com <- merge(GID_L_tmp_mod_table,GID_gdend, by="GID")
                GID_L_tmp_mod_com$index <- as.numeric(GID_L_tmp_mod_com$index)
                GID_L_tmp_mod_sort <- GID_L_tmp_mod_com[order(GID_L_tmp_mod_com$index),]
                GID_L_tmp_mod_sort$index <- NULL
          
                ###
                uGID_in <-  GID_L_tmp_mod_sort[,2:ncol(GID_L_tmp_mod_sort)]
                rownames(uGID_in) <-  GID_L_tmp_mod_sort[,1]
               
                uGID_in$F<-ifelse(uGID_in$F=='1', 1,0)
                uGID_in$G<-ifelse(uGID_in$G=='1', 2,0)
                uGID_in$K<-ifelse(uGID_in$K=='1', 3,0)
                uGID_in$S<-ifelse(uGID_in$S=='1', 4,0)
                      
                par(mar = c(4,1,1,12))
                plot(gdend, horiz = TRUE)
                labels_colors(gdend) <- "white"
                colored_bars(uGID_in[,c(4, 3, 2, 1)], gdend, sort_by_labels_order=FALSE, rowLabels=uLoc_all, horiz = TRUE)
                #legend("topleft", legend = levels(uLoc_all), fill = cols_4)
                
                
            ####################
            # 2.3.2.2. Identify unique QTL genotypes
            ####################
            
            qsdata_select <- gsdata_prep[,colnames(gsdata_prep)%in%qs_SID]
            
            qsdata_GID <- qsdata_select
            qsdata_GID$GID <- rownames(qsdata_GID)
            rownames(qsdata_GID) <- NULL
            
            qsdata_temp <- qsdata_select
            rownames(qsdata_temp) <- NULL
            
            qsdata_QID <- unique(qsdata_temp)
            rownames(qsdata_QID) <-  paste("QG",rownames(qsdata_QID),sep="")
            nrow(qsdata_QID)
            
            qsdata_QID_temp <- qsdata_QID
            
            qsdata_QID_temp$QID <- rownames(qsdata_QID_temp)
            rownames(qsdata_QID_temp) <- NULL
            
            qsdata_GID_QID <- merge(qsdata_GID,qsdata_QID_temp)
            
            GID_QID_list <- unique(qsdata_GID_QID[,c("GID","QID")])
            
            qsdata_select <- gsdata_prep[,colnames(gsdata_prep)%in%qs_SID]
            qsdata_GID <- qsdata_select
            qsdata_GID$GID <- NULL
    
            ### Move the QID column to first
            
            qsdata_QID_temp_mod <- qsdata_QID_temp[,c(which(colnames(qsdata_QID_temp)=="QID"),which(colnames(qsdata_QID_temp)!="QID"))]
        
   
                ####################
                # 2.3.2.2.1. Cluster plot for QTL population
                ####################
                
                uqsdata_GID <-  qsdata_QID_temp_mod[,2:ncol(qsdata_QID_temp_mod)]
                rownames(uqsdata_GID) <- qsdata_QID_temp_mod[,1]
                
                qsdata_QID_mat <- dist(uqsdata_GID, method ="euclidean")
                hc_QTL <- hclust(qsdata_QID_mat)
                plot(as.phylo(hc_QTL), type = "unrooted", cex = 0.6, label.offset = 0.5)
                 
                dend <- as.dendrogram(hclust(qsdata_QID_mat), method= "wards.D2")
                
                ### QID as in dend order
                QID_dend <- as.data.frame(labels(dend))
                QID_dend$index <- rownames(QID_dend)
                colnames(QID_dend) [1] <- "QID"
                ### Extract the QID and Location field from the pdata
                QID_L_tmp <- unique(apdata_513[,c("QID","L")])
               
                uLoc <- unique(QID_L_tmp$L)
                uLoc <- sort(factor(uLoc), decreasing=TRUE)
                
                # cols_4 <- colorspace::rainbow_hcl(uLoc, c = 70, l  = 50)
           
                n_Loc <- length(unique(uLoc))
                cols_4 = c("black", "red", "green", "blue")
                 
                QID_L_tmp_mod <- table(QID_L_tmp$QID, QID_L_tmp$L)
                QID_L_tmp_mod_table <- as.data.frame.matrix(QID_L_tmp_mod) 
                
                QID_L_tmp_mod_table$QID <- rownames(QID_L_tmp_mod_table)
                
                ### Combine and give and index for the order
                QID_L_tmp_mod_com <- merge(QID_L_tmp_mod_table,QID_dend, by="QID")
                QID_L_tmp_mod_com$index <- as.numeric(QID_L_tmp_mod_com$index)
                QID_L_tmp_mod_sort <- QID_L_tmp_mod_com[order(QID_L_tmp_mod_com$index),]
                QID_L_tmp_mod_sort$index <- NULL
          
                ###
                uQID_QTL_in <-  QID_L_tmp_mod_sort[,2:ncol(QID_L_tmp_mod_sort)]
                rownames(uQID_QTL_in) <-  GID_QID_L_tmp_mod_sort[,1]
               
                uQID_QTL_in$F<-ifelse(uQID_QTL_in$F=='1', 1,0)
                uQID_QTL_in$G<-ifelse(uQID_QTL_in$G=='1', 2,0)
                uQID_QTL_in$K<-ifelse(uQID_QTL_in$K=='1', 3,0)
                uQID_QTL_in$S<-ifelse(uQID_QTL_in$S=='1', 4,0)
                      
                par(mar = c(4,1,1,7))
                plot(dend, horiz = TRUE)
                labels_colors(dend) <- "white"
                colored_bars(uQID_QTL_in[,c(4, 3, 2, 1)], dend,sort_by_labels_order=FALSE, rowLabels=uLoc, horiz = TRUE)
                #legend("topleft", legend = levels(uLoc), fill = cols_4)
                
    ######################
              # 2.3.3.4.Fst in R package
              ######################
               library(StAMPP)
                    
              uGID_L_tmp <- GID_L_tmp[!duplicated(GID_L_tmp$GID),]
              gsdata_prep_com <- merge(gsdata_prep_mod, uGID_L_tmp, by="GID")
              
              ### Prepare input file
              M <- gsdata_prep_mod
              M[M==0] = "AA"
              M[M==1] = "AB"
              M[M==2] = "BB"
              
              ### rename L to pop
              M <- data.frame(GID = row.names(M), M)
              Fst_in_tmp <- merge(M, uGID_L_tmp, by="GID")
              Fst_in_tmp$format <- "BiA"
              Fst_in_tmp$ploidy <- "2"
              ### rename L to pop
              Fst_in_tmp <- rename(Fst_in_tmp, c("L"="pop"))
              
              ### re order the column in bring GID, pop, ploidy, and format to first
              
              Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .before = GID)
              Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .after = GID)
              Fst_in_tmp <- as.data.frame(Fst_in_tmp)
              
              Fst_in_mod <- Fst_in_tmp
              
              Fst_in <- stamppConvert(Fst_in_mod, type="r")
              
              ###  global pairwise Fst
              
              Fst_output <- stamppFst(Fst_in, nboots=200, percent=95, nclusters = 4)
              Fst_output$Fsts
             
                         
                
                


  
 
    ############################################################
    # 2.4. Review of QTLpdata
    ###########################################################
                
        ########################################
        # 2.4.1 QTL pdata
        ########################################
         
            ##########################
            # 2.4.1.1. Congreunce of entries in the QTL
            ##########################

            uLYG_QTL <- unique(apdata_513[,c("QID","LY")])
            uLYxG_QTL <- table(uLYG_QTL$QID, uLYG_QTL$LY)
            G_LYcong_QTL <- t(uLYxG_QTL)%*%uLYxG_QTL

            write.csv(G_LYcong_QTL,"../3. Genetic structure/G_LYong_QTL.csv")
            