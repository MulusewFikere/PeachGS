#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#
# Complete script for Cluster and LD plot for peach GxE paper
#
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 1. Load data ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

load("../../2. Curation/Curated_data.RData")

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 2. Tables ofcommon genotypes
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
uQL <-unique(pdata_cur[,c("QID","L")])

uQxL <- table(uQL$QID,uQL$L)

uQxL_tab <- t(uQxL)%*%uQxL

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 4.Fst in R package
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
pdata_cur$pop <- "TAMU"
pdata_cur$pop[pdata_cur$L == "K"] <- "UARK"
pdata_cur$pop[pdata_cur$L == "S"] <- "CLEM"

library(StAMPP, attach.required = T)
    
#<<<< Create biallic object
M <- as.data.frame(wsdata_cur)
M[M==0] = "AA"
M[M==1] = "AB"
M[M==2] = "BB"

#<<<< 
M_GID <- M
M_GID$GID <- rownames(M)

uGID_pop <- unique(pdata_cur[,c("GID","pop")])

M_GID_pop <-merge(uGID_pop,M_GID)

#<<<< Prepare Fst_in_tmp
Fst_in_tmp <- M_GID_pop
Fst_in_tmp$format <- "BiA"
Fst_in_tmp$ploidy <- "2"

#<<<< re order the column in bring GID, pop, ploidy, and format to first
library(dplyr)
Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .before = GID)
Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .after = GID)
Fst_in_tmp <- as.data.frame(Fst_in_tmp)

Fst_in <- stamppConvert(Fst_in_tmp, type="r")
Fst_output <- stamppFst(Fst_in)#, nboots=200, percent=95, nclusters = 4)
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 5. Gene frequency by pop
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
pdata_extra <- pdata_cur

pdata_extra$BPOP <- "TAMU"
pdata_extra$BPOP[pdata_extra$L == "K"] <- "UARK"
pdata_extra$BPOP[pdata_extra$L == "S"] <- "CLEM"

uGB <- unique(pdata_extra[,c("GID","BPOP")])    

freq <- as.data.frame(colnames(wsdata_cur))
colnames(freq) <- "SID"

na <- 2*nrow(wsdata_cur)

nref_all <- colSums(wsdata_cur)

freq$freq_ALL <- nref_all/na

for(b in unique(uGB$BPOP))
    {
    # b <- unique(uGB$BPOP)[1]
    
    GID_b <- uGB$GID[uGB$BPOP == b]
    
    wsdata_b <- wsdata_cur[rownames(wsdata_cur)%in%GID_b,]
    
    nref_b <- colSums((wsdata_b))
    na_b <- 2*nrow(wsdata_b)
    freq_b <- as.data.frame(nref_b/na_b)
    colnames(freq_b) <- paste("freq_",b,sep="")
    freq_b$SID <- rownames(freq_b)
    
    freq <- merge(freq,freq_b, all = T)
}
    
plot(freq$freq_ALL,freq$freq_TAMU)
plot(freq$freq_ALL,freq$freq_UARK)
plot(freq$freq_ALL,freq$freq_CLEM)

plot(freq$freq_TAMU,freq$freq_UARK)
plot(freq$freq_TAMU,freq$freq_CLEM)
plot(freq$freq_UARK,freq$freq_CLEM)

cor(freq$freq_ALL,freq$freq_TAMU)
cor(freq$freq_ALL,freq$freq_UARK)
cor(freq$freq_ALL,freq$freq_CLEM)

cor(freq$freq_TAMU,freq$freq_UARK)
cor(freq$freq_TAMU,freq$freq_CLEM)
cor(freq$freq_UARK,freq$freq_CLEM)

