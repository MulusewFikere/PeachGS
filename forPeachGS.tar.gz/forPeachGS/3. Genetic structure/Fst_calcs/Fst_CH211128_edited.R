################################################################################
#
# Complete script for Cluster and LD plot for peach GxE paper
#
################################################################################

###############################################################################
# 2. Load curated data ####
###############################################################################

load("../../2. Curation/Curated_data.RData")
    
###############################################################################
# 4.Fst in R package
###############################################################################
    
   
    ###########################################################################
    # 2.3.3.4.Fst in R package
    ######################
    
               library(StAMPP)
                    
              uGID_L_tmp <- GID_L_tmp[!duplicated(GID_L_tmp$GID),]
              gsdata_prep_com <- merge(gsdata_prep_mod, uGID_L_tmp, by="GID")
              
              ### Prepare input file
              M <- gsdata_prep_mod
              M[M==0] = "AA"
              M[M==1] = "AB"
              M[M==2] = "BB"
              
              ### rename L to pop
              M <- data.frame(GID = row.names(M), M)
              Fst_in_tmp <- merge(M, uGID_L_tmp, by="GID")
              Fst_in_tmp$format <- "BiA"
              Fst_in_tmp$ploidy <- "2"
              ### rename L to pop
              Fst_in_tmp <- rename(Fst_in_tmp, c("L"="pop"))
              
              ### re order the column in bring GID, pop, ploidy, and format to first
              
              Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .before = GID)
              Fst_in_tmp <-  Fst_in_tmp %>%  relocate(pop, ploidy,format, .after = GID)
              Fst_in_tmp <- as.data.frame(Fst_in_tmp)
              
              Fst_in_mod <- Fst_in_tmp
              
              Fst_in <- stamppConvert(Fst_in_mod, type="r")
              
              ###  global pairwise Fst
              
              Fst_output <- stamppFst(Fst_in, nboots=200, percent=95, nclusters = 4)
              Fst_output$Fsts
    

            