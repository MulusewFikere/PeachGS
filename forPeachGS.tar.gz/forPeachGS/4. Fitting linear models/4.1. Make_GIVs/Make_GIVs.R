#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#
# Complete script for linear mixed model analysis of peach GxE paper
#
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 1. Set R 4.1.0 ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

library(ASRgenomics)

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# 2. prepare data ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 2.2. pdata ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    pdata_cur <- read.csv("../../2. Curation/pdata_cur.csv")
                
    length(unique(pdata_cur$GID))
    length(unique(pdata_cur$QID))
    
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.2.1. Remove GID with no phenotypic data ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
        GID_nna <- unique(pdata_cur$GID[!is.na(pdata_cur$snewy)])
        length(GID_nna)
        
        pdata_nna <- pdata_cur[pdata_cur$GID%in%GID_nna,]
        length(unique(pdata_nna$GID))
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.2.2. Review of pdata
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<< Number of GID
        length(unique(pdata_nna$GID))
        
        #<<<< nGIDxL
        uG_L <- unique(pdata_nna[,c("GID","L")])
        nGxL <- table(uG_L$GID,uG_L$L)
        t(nGxL)%*%nGxL
            
        #<<<< Number od QID
        length(unique(pdata_nna$QID))
        
        #<<<< nQIDxL
        uQ_L <- unique(pdata_nna[,c("QID","L")])
        nQxL <- table(uQ_L$QID,uQ_L$L)
        t(nQxL)%*%nQxL
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 2.3. sdata ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.3.1. wsdata ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        wsdata_cur_in <- read.csv("../../2. Curation/wsdata_cur.csv")
        wsdata_cur <- wsdata_cur_in[,2:ncol(wsdata_cur_in)]
        rownames(wsdata_cur) <- wsdata_cur_in[,1]
        
            #<<<<<<<<<<<<<<<<<<<
            # 2.3.1.1. Format data
            #<<<<<<<<<<<<<<<<<<<
        
            wsdata_nna <- as.matrix(wsdata_cur[rownames(wsdata_cur)%in%GID_nna,])
            nrow(wsdata_nna)

            #<<<<<<<<<<<<<<<<<<<
            # 2.3.1.2. Remove duplicates
            #<<<<<<<<<<<<<<<<<<<
    
            #<<<< Make GRM    
            AW.grm_nna <- G.matrix(wsdata_nna)$G
            
            #<<<< Find duplciates in grm_nna
            wsdata_duplicates <- kinship.diagnostics(AW.grm_nna)$list.duplicate
            
            #<<<< Remove duplicates
            wsdata_uG <- wsdata_nna[!rownames(wsdata_nna)%in%c(wsdata_duplicates$Indiv.B),]
            nrow(wsdata_uG)
        
            #<<<< GRM from wsdata_u
            AW.grm_uG <- G.matrix(wsdata_uG)$G
            
            #<<<< Find duplciates in grm_u
            wsdata_duplicates_uG <- kinship.diagnostics(AW.grm_uG)$list.duplicate
            
            #<<<<<<<<<<<<<<<<<<<
            # 2.3.1.3. modify pdata
            #<<<<<<<<<<<<<<<<<<<
            
            pdata_uG <- pdata_nna
            pdata_uG$GID_org <- pdata_uG$GID
            
            for(i in 1:nrow(wsdata_duplicates))
            {
            pdata_uG$GID[pdata_uG$GID_org%in%wsdata_duplicates$Indiv.B[i]] <- wsdata_duplicates$Indiv.A[i]
            }
            length(unique(pdata_uG$GID_org))
            length(unique(pdata_uG$GID))
                
            pdata_uG[pdata_uG$GID%in%c(wsdata_duplicates$Indiv.A,wsdata_duplicates$Indiv.B),]
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.2.2. Lists of unique GID by site ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                
        GID_list <- unique(pdata_uG$GID)
        length(GID_list)

        GID_list_F <- unique(pdata_uG$GID[pdata_uG$L == "F"])
        length(GID_list_F)
        
        GID_list_G <- unique(pdata_uG$GID[pdata_uG$L == "G"])
        length(GID_list_G)
        
        GID_list_K <- unique(pdata_uG$GID[pdata_uG$L == "K"])
        length(GID_list_K)
        
        GID_list_S <- unique(pdata_uG$GID[pdata_uG$L == "S"])
        length(GID_list_S)
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 2.3. sdata ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.3.1. wsdata ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        wsdata <- wsdata_uG[rownames(wsdata_uG)%in%GID_list,]
        nrow(wsdata)
        
        wsdata_F <- wsdata[rownames(wsdata)%in%GID_list_F,]
        wsdata_G <- wsdata[rownames(wsdata)%in%GID_list_G,]
        wsdata_K <- wsdata[rownames(wsdata)%in%GID_list_K,]
        wsdata_S <- wsdata[rownames(wsdata)%in%GID_list_S,]
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.3.2. qsdata ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        q_sid <- read.csv("../../2. Curation/q_sid.csv")
        
        qsdata <- wsdata[,colnames(wsdata)%in%q_sid]
        nrow(qsdata)
        ncol(qsdata)

        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.3.3. bsdata ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        bsdata <- wsdata[,!colnames(wsdata)%in%colnames(qsdata)]
        nrow(bsdata)
        
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 3. Construct raw GRMS using ASRgenomics ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 3.1. Genome wide ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 3.1.1. Individal trials ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<< F
        AW.grm_F <- G.matrix(wsdata_F, method = "VanRaden")$G 
        DW.grm_F <- G.matrix(wsdata_F, method = "Su")$G 
            
        #<<<<< G
        AW.grm_G <- G.matrix(wsdata_G, method = "VanRaden")$G 
        DW.grm_G <- G.matrix(wsdata_G, method = "Su")$G 
        
        #<<<<< K
        AW.grm_K <- G.matrix(wsdata_K, method = "VanRaden")$G 
        DW.grm_K <- G.matrix(wsdata_K, method = "Su")$G 
        
        #<<<<< S
        AW.grm_S <- G.matrix(wsdata_S, method = "VanRaden")$G 
        DW.grm_S <- G.matrix(wsdata_S, method = "Su")$G 
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 3.1.2. Cross trials ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        AW.grm <- G.matrix(wsdata, method = "VanRaden")$G 
        DW.grm <- G.matrix(wsdata, method = "Su")$G 
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 3.2. QTL region cross trial
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
    #<<<< Make aGIDxQID table
    GID_QID_key <- unique(pdata_uG[,c("GID","QID")])
    GIDxQID <- table(GID_QID_key$GID,GID_QID_key$QID)
    nGIDxQID <-  t(GIDxQID)%*%GIDxQID
    
    #<<<<< Additive
    AQ.grm_GID <- G.matrix(qsdata, method = "VanRaden")$G
    AQ.grm_QID <- (solve(nGIDxQID)%*%t(GIDxQID))%*%(AQ.grm_GID)%*%(GIDxQID%*%solve(nGIDxQID))
    
    #<<<<< Dominance
    DQ.grm_GID <- G.matrix(qsdata, method = "Su")$G
    DQ.grm_QID <- (solve(nGIDxQID)%*%t(GIDxQID))%*%(DQ.grm_GID)%*%(GIDxQID%*%solve(nGIDxQID))

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 3.3. Background cross trial
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
    AB.grm <- G.matrix(bsdata, method = "VanRaden")$G 
    DB.grm <- G.matrix(bsdata, method = "Su")$G 

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 6. G inverse using G.tune  ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.1. Genome wide ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 6.1.1. Individual trials ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<< F
        AW.grm_F_tune <- G.tuneup(AW.grm_F, bend = T)$G
        AW.giv_F_tune <- G.inverse(AW.grm_F_tune)$G
        
        DW.grm_F_tune <- G.tuneup(DW.grm_F, bend = T)$G
        DW.giv_F_tune <- G.inverse(DW.grm_F_tune)$G
        
        #<<<<< G
        AW.grm_G_tune <- G.tuneup(AW.grm_G, bend = T)$G
        AW.giv_G_tune <- G.inverse(AW.grm_G_tune)$G
        
        DW.grm_G_tune <- G.tuneup(DW.grm_G, bend = T)$G
        DW.giv_G_tune <- G.inverse(DW.grm_G_tune)$G
        
        #<<<<< K
        AW.grm_K_tune <- G.tuneup(AW.grm_K, bend = T)$G
        AW.giv_K_tune <- G.inverse(AW.grm_K_tune)$G
        
        DW.grm_K_tune <- G.tuneup(DW.grm_K, bend = T)$G
        DW.giv_K_tune <- G.inverse(DW.grm_K_tune)$G
        
        #<<<<< S
        AW.grm_S_tune <- G.tuneup(AW.grm_S, bend = T)$G
        AW.giv_S_tune <- G.inverse(AW.grm_S_tune)$G
        
        DW.grm_S_tune <- G.tuneup(DW.grm_S, bend = T)$G
        DW.giv_S_tune <- G.inverse(DW.grm_S_tune)$G
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 6.1.2. Cross trials ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        AW.grm_tune <- G.tuneup(AW.grm, bend = T)$G
        AW.giv_tune <- G.inverse(AW.grm_tune)$G
        
        DW.grm_tune <- G.tuneup(DW.grm, bend = T)$G
        DW.giv_tune <- G.inverse(DW.grm_tune)$G

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.2. QTL cross trial ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
    AQ.grm_QID_tune <- G.tuneup(AQ.grm_QID, bend = T)$G
    AQ.giv_QID_tune <- G.inverse(AQ.grm_QID_tune)$G
        
    DQ.grm_QID_tune <- G.tuneup(DQ.grm_QID, bend = T)$G
    DQ.giv_QID_tune <- G.inverse(DQ.grm_QID_tune)$G

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.3. background cross trial ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
    AB.grm_tune <- G.tuneup(AB.grm, bend = T)$G
    AB.giv_tune <- G.inverse(AB.grm_tune)$G
        
    DB.grm_tune <- G.tuneup(DB.grm, bend = T)$G
    DB.giv_tune <- G.inverse(DB.grm_tune)$G

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 7. Plot GRM elements
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 7.1. FG
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    #<<<< SIngle trial GRM
    GID_list_FG  <- unique(pdata_uG$GID[pdata_uG$L == "F" | pdata_uG$L == "G"])
    wsdata_FG <- wsdata[rownames(wsdata)%in%GID_list_FG,]
        
    AW.grm_FG <- G.matrix(wsdata_FG, method = "VanRaden")$G 
           
    #
    AW.grm_FG_sel <- AW.grm[rownames(AW.grm) %in% GID_list_FG, colnames(AW.grm) %in% GID_list_FG]
       
    plot(AW.grm_FG_sel[upper.tri(AW.grm_FG_sel)],AW.grm_FG[upper.tri(AW.grm_FG)])
    cor(AW.grm_FG_sel[upper.tri(AW.grm_FG_sel)],AW.grm_FG[upper.tri(AW.grm_FG)])
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 7.2. K
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    AW.grm_K_sel <- AW.grm[rownames(AW.grm) %in% GID_list_K, colnames(AW.grm) %in% GID_list_K]
       
    plot(AW.grm_K_sel[upper.tri(AW.grm_K_sel)],AW.grm_K[upper.tri(AW.grm_K)])
    cor(AW.grm_K_sel[upper.tri(AW.grm_K_sel)],AW.grm_K[upper.tri(AW.grm_K)])
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 7.3. S
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    AW.grm_S_sel <- AW.grm[rownames(AW.grm) %in% GID_list_S, colnames(AW.grm) %in% GID_list_S]
       
    plot(AW.grm_S_sel[upper.tri(AW.grm_S_sel)],AW.grm_S[upper.tri(AW.grm_S)])
    cor(AW.grm_S_sel[upper.tri(AW.grm_S_sel)],AW.grm_S[upper.tri(AW.grm_S)])
    
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 7. save RData
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
save.image('Make_GIVs.RData')
    

