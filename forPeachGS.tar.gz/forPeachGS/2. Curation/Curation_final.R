################################################################################
#
# Complete script for linear mixed model analysis of peach GxE paper
#
################################################################################

################################################################################
# 1. Preliminary
################################################################################

    ############################################################
    # 1.2. Load libraries
    ############################################################

    # library(rgl, lib.loc = "C:/Users/uqchardn/Dropbox/CURRENT/R/R-3.6.3/library")
    # library(snpReady, lib.loc = "C:/Users/uqchardn/Dropbox/CURRENT/R/R-3.6.3/library")

###############################################################################
# 2. Prepare data
###############################################################################
    
    ############################################################
    # 2.1. Read in data
    ############################################################
    
        ########################################
        # 2.1.1. pdata
        ########################################
    
        phdata_in <- read.csv("../0. Data/phdata_prep.csv", stringsAsFactors = F)
    
        ########################################
        # 2.1.2. sdata
        ########################################
    
            ####################
            # 2.1.2.1. GW sdata
            ####################
        
            wsdata_in <- read.csv("../0. Data/wsdataxGID_prep.csv", stringsAsFactors = F)
            wsdata_temp <- wsdata_in[,2:ncol(wsdata_in)]
            rownames(wsdata_temp) <- wsdata_in[,1]
            ncol(wsdata_temp)
        
            ####################
            # 2.1.2.2 QTL sdata
            ####################
            
            qsdata_in <- read.csv("../0. Data/qsdataxQID_prep.csv", stringsAsFactors = F)
            qsdata_temp <- qsdata_in[,2:ncol(qsdata_in)]
            rownames(qsdata_temp) <- qsdata_in[,1]
            ncol(qsdata_temp)
            
            q_sid <- colnames(qsdata_in[,2:ncol(qsdata_in)])
        
            ####################
            # 2.1.2.4. Read the mapFile
            ####################
            
            #### Read the map file and subset bSNPs
            mapFile <- read.csv("../0. Data/map_sdata_MF201214.csv",header = T)
            
        ########################################
        # 2.1.3. Extract data for ID with pdata and wsdata
        ########################################
            
        ID_pdata <- unique(phdata_in$GID)
        ID_sdata <- unique(wsdata_in$X)
            
        ID_pdata[!ID_pdata%in%ID_sdata]
        ID_sdata[!ID_sdata%in%ID_pdata]
        
        pdata_cur <- phdata_in
        
###############################################################################
# 3. Curation of sdata
###############################################################################
    
    ############################################################
    # 3.1. wsdata
    ############################################################
    
    wsdata_snpReady <- as.matrix(wsdata_temp)
    wsdata_QC_out <- raw.data(wsdata_snpReady, frame = "wide", base = FALSE, call.rate = 0.85, maf = 0.05, 
                                         imput = TRUE, imput.type = "mean", outfile = "012", plot = TRUE)
    wsdata_cur <- wsdata_QC_out$M.clean
    
    save(pdata_cur,wsdata_cur,q_sid, file = "Curated_data.RData")

    write.csv(pdata_cur,"pdata_cur.csv",row.names = F)
    write.csv(wsdata_cur,"wsdata_cur.csv")
    write.csv(q_sid,"q_sid.csv",row.names = F)
    