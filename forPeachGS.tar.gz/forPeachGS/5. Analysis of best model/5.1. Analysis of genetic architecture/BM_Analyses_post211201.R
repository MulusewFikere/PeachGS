#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#
# Complete script for linear mixed model analysis of peach GxE paper
#
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 1. Preliminary ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 1.2. Load libraries ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    library(gtools)
    library(asreml)  
    
    options(scipen = 999)
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
# 2. prepare data ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<#
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 2.1. Load curated data ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    load("../../4. Fitting linear models/4.4. XQBX/XQBX_210918.RData")
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 2.2. keys
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.2.1. GW analyses ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
        apdata$E <- as.character(apdata$LY)
        
        apdata$E[apdata$L == 'F'] <- 'F'
        apdata$E[apdata$L == 'G'] <- 'G'
        apdata$E[apdata$LY== 'K0' | apdata$LY == 'K1'] <- 'K01'
        
        unique(apdata$E)
        
        AW_Ekey <- unique(apdata[,c("AE4","E")])       
        AW_Ekey
        
        AW_Ekey.M <- as.matrix(table(AW_Ekey$AE4,AW_Ekey$E))
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 2.2.1. QB analyses ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
        apdata$E <- as.character(apdata$LY)
        
        apdata$E[apdata$L == 'F'] <- 'F'
        apdata$E[apdata$L == 'G'] <- 'G'
        apdata$E[apdata$LY== 'K0' | apdata$LY == 'K1'] <- 'K01'
        
        unique(apdata$E)
        
        AB_Ekey <- unique(apdata[,c("fAB1","E")])       
        AB_Ekey        
        
        AB_Ekey.M <- as.matrix(table(AB_Ekey$fAB1,AB_Ekey$E))
        
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 3. Correlation tables and dendograms ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 3.1. XGWM07 analyses ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 3.1.1. Correlations ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
     
        #<<<< Additive   
        XGWM07_Mvcov_AWxAE <-  XGWM07.Mvcov_AW$Mvcov   
        XGWM07_Mr_AWxAE <- cov2cor(XGWM07_Mvcov_AWxAE)
        XGWM07_Mr_AWxAE_df <- as.data.frame(XGWM07_Mr_AWxAE)
        XGWM07_Mr_AWxAE_df$source <-"AW"
    
        #<<<< Total genomic
        XGWM07_v_DW <- XGWM07.asr$vparameters[grepl("DW",names(XGWM07.asr$vparameters))]
        
        XGWM07_Mvcov_GWxAE <- XGWM07_Mvcov_AWxAE + XGWM07_v_DW
        XGWM07_Mr_GWxAE <- cov2cor(XGWM07_Mvcov_GWxAE)
        XGWM07_Mr_GWxAE_df <- as.data.frame(XGWM07_Mr_GWxAE)
        XGWM07_Mr_GWxAE_df$source <-"GW"
            
        XGWM07_Mr_xAE_out <- rbind(XGWM07_Mr_AWxAE_df,XGWM07_Mr_GWxAE_df)
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 3.1. Dendograms xAE ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
        #<<<< AW dendogram of correlations
        plot(as.dendrogram(hclust(dist(XGWM07_Mr_GWxAE), method = 'ward.D2')), horiz = T, xlab = "GW")
    
        #<<<< GW dendogram
        plot(as.dendrogram(hclust(dist(XGWM07_Mr_AWxAE), method = 'ward.D2')), horiz = T, xlab = "AW")
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 3.2. XQBMB1 analyses ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 3.2.1. Correlations ####
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
     
            #<<<<<<<<<<<<<<<<<<<
            # 3.2.1.1. Additive ####
            #<<<<<<<<<<<<<<<<<<<
        
            #<<<< Background
            XQBMB1_Mvcov_ABxAE <-  XQBMB1.Mvcov_AB$Mvcov   
            XQBMB1_Mr_ABxAE <- cov2cor(XQBMB1_Mvcov_ABxAE)
            XQBMB1_Mr_ABxAE_df <- as.data.frame(XQBMB1_Mr_ABxAE)
            XQBMB1_Mr_ABxAE_df$source <-"AB"
    
            #<<<< QTL
            XQBMB1_v_AQ <- XQBMB1.asr$vparameters[grepl("AQ",names(XQBMB1.asr$vparameters))]
            
            #<<<<AQB
            XQBMB1_Mvcov_AQBxAE <- XQBMB1_Mvcov_ABxAE + XQBMB1_v_AQ
        
            XQBMB1_Mr_AQBxAE <- cov2cor(XQBMB1_Mvcov_AQBxAE)
            XQBMB1_Mr_AQBxAE_df <- as.data.frame(XQBMB1_Mr_AQBxAE)
            XQBMB1_Mr_AQBxAE_df$source <-"AQB"
            
            #<<<<<<<<<<<<<<<<<<<
            # 3.2.1.1. Total genomic ####
            #<<<<<<<<<<<<<<<<<<<
        
            #<<<< Total genomic
            XQBMB1_v_DB <- XQBMB1.asr$vparameters[grepl("DB",names(XQBMB1.asr$vparameters))]
            
            XQBMB1_Mvcov_GQBxAE <- XQBMB1_Mvcov_AQBxAE + XQBMB1_v_DB
            XQBMB1_Mr_GQBxAE <- cov2cor(XQBMB1_Mvcov_GQBxAE)
            XQBMB1_Mr_GQBxAE_df <- as.data.frame(XQBMB1_Mr_GQBxAE)
            XQBMB1_Mr_GQBxAE_df$source <-"GQB"
                
            XQBMB1_Mr_xAE_out <- rbind(XQBMB1_Mr_ABxAE_df,XQBMB1_Mr_AQBxAE_df,XQBMB1_Mr_GQBxAE_df)
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 3.2.2. Dendograms xAE ###
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        #<<<< AB dendogram
        plot(as.dendrogram(hclust(dist(XQBMB1_Mr_ABxAE), method = 'ward.D2')), horiz = T, xlab = "AB")
        
        #<<<< AQB dendogram
        plot(as.dendrogram(hclust(dist(XQBMB1_Mr_AQBxAE), method = 'ward.D2')), horiz = T, xlab = "AQB")
        
        #<<<< GQB dendogram of correlations
        plot(as.dendrogram(hclust(dist(XQBMB1_Mr_GQBxAE), method = 'ward.D2')), horiz = T, xlab = "GQB")
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 3.3 Correlations combined ####
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    X_Mr_xAE_out <- rbind(XGWM07_Mr_xAE_out,XQBMB1_Mr_xAE_out)
        
    write.csv(X_Mr_xAE_out,'X_Mr_xAE_out.csv')
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 4. Predicted values ####
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 4.1. Individual trials
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    load("../../4. Fitting linear models/4.2. IGWIP/.RData")
    
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        # 4.1.1. Fresno
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
            #<<<<<<<<<<<<<<<<<<<
            # 4.1.1.1. Fit model ####
            #<<<<<<<<<<<<<<<<<<<
            
            FGWFU03.asr <- asreml(snewy ~ 1 + Y,
                                    random = ~ vm(AGID,AW.giv_F_tune) +  
                                                vm(DGID,DW.giv_F_tune) + 
                                                U, 
                                    data= apdata_F,
                                    na.action = na.method(y = "include", x = "include"),
                                    workspace = 6e+08,
                                    maxiter=50)
            
            #<<<<<<<<<<<<<<<<<<<
            # 4.1.1.2. Predictions
            #<<<<<<<<<<<<<<<<<<<
    
            FGW_bAW <- predict(FGWFU03.asr,classify = "AGID", only ='vm(AGID, AW.giv_F_tune)',maxit = 1)$pvals[,1:2]
            colnames(FGW_bAW) <- c("GID","FGW_bAW")
            
            FGW_bDW <- predict(FGWFU03.asr,classify = "DGID", only ='vm(DGID, AW.giv_F_tune)',maxit = 1)$pvals[,1:2]
            colnames(FGW_bDW) <- c("GID","FGW_bDW")
            
            FGW_bGW <- merge(FGW_bAW,FGW_bDW)
            FGW_bGW$FGW_bGW <- FGW_bGW$FGW_bAW + FGW_bGW$FGW_bDW
            
            FGW_bGW$GID <- as.character(FGW_bGW$GID)
            
            colnames(FGW_bGW) <- sub("FGW","IGW",colnames(FGW_bGW))
            FGW_bGW$AE <- "F"
            
            FGW_bGW$L <- "F"
            
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        # 4.1.2. College Station
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
            #<<<<<<<<<<<<<<<<<<<
            # 4.1.2.2. Predictions
            #<<<<<<<<<<<<<<<<<<<
    
            GGW_bAW <- predict(GGWGU03.asr,classify = "AGID", only ='vm(AGID, AG_G.giv)',maxit = 1)$pvals[,1:2]
            colnames(GGW_bAW) <- c("GID","GGW_bAW")
            
            GGW_bDW <- predict(GGWGU03.asr,classify = "DGID", only ='vm(DGID, DG_G.giv)',maxit = 1)$pvals[,1:2]
            colnames(GGW_bDW) <- c("GID","GGW_bDW")
            
            GGW_bGW <- merge(GGW_bAW,GGW_bDW)
            GGW_bGW$GGW_bGW <- GGW_bGW$GGW_bAW + GGW_bGW$GGW_bDW
            
            GGW_bGW$GID <- as.character(GGW_bGW$GID)

            colnames(GGW_bGW) <- sub("GGW","IGW",colnames(GGW_bGW))
            GGW_bGW$AE <- "G"

            GGW_bGW$L <- "G"
            
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        # 4.1.3. Clarksville
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
            #<<<<<<<<<<<<<<<<<<<
            # 4.1.2.2. Predictions
            #<<<<<<<<<<<<<<<<<<<
    
            KGW_bAW <- predict(KGWKM06.asr,classify = "vm(AGID, AG_K.giv):KAE1",maxit = 1)$pvals[,1:3]
            colnames(KGW_bAW) <- c("GID","AE","KGW_bAW")
            
            KGW_bDW <- predict(KGWKM06.asr,classify = "DGID", only ='vm(DGID, DG_K.giv)',maxit = 1)$pvals[,1:2]
            colnames(KGW_bDW) <- c("GID","KGW_bDW")
            
            KGW_bGW <- merge(KGW_bAW,KGW_bDW)
            KGW_bGW$KGW_bGW <- KGW_bGW$KGW_bAW + KGW_bGW$KGW_bDW

            colnames(KGW_bGW) <- sub("KGW","IGW",colnames(KGW_bGW))
            
            KGW_bGW$AE <- as.character(KGW_bGW$AE)
            KGW_bGW$GID <- as.character(KGW_bGW$GID)
            
            KGW_bGW$AE[KGW_bGW$AE == "K01"] <- "K01S2"
            KGW_bGW$AE[KGW_bGW$AE == "2"] <- "K2"
            
            KGW_bGW$L <- "K"
            
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        # 4.1.4. Seneca
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
            #<<<<<<<<<<<<<<<<<<<
            # 4.1.2.2. Predictions
            #<<<<<<<<<<<<<<<<<<<
    
            SGW_bAW <- predict(SGWSM02a.asr,classify = "AGID:Y", only = "vm(AGID, AG_S.giv):Y", maxit = 1)$pvals[,1:3]
            colnames(SGW_bAW) <- c("GID","AE","SGW_bAW")
            
            SGW_bDW <- predict(SGWSM06.asr,classify = "DGID", only ='vm(DGID, DG_S.giv)',maxit = 1)$pvals[,1:2]
            colnames(SGW_bDW) <- c("GID","SGW_bDW")
            
            SGW_bGW <- merge(SGW_bAW,SGW_bDW)
            SGW_bGW$SGW_bGW <- SGW_bGW$SGW_bAW + SGW_bGW$SGW_bDW

            colnames(SGW_bGW) <- sub("SGW","IGW",colnames(SGW_bGW))
            
            SGW_bGW$AE <- as.character(SGW_bGW$AE)
            SGW_bGW$GID <- as.character(SGW_bGW$GID)
            
            SGW_bGW$AE <- paste("S",SGW_bGW$AE,sep="")

            SGW_bGW$AE[SGW_bGW$AE == "S2"] <- 'K01S2'
            
            SGW_bGW$L <- "S"
            
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 4.1.5. 
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        IGW_bGW <- rbind(FGW_bGW,GGW_bGW,KGW_bGW,SGW_bGW)

        L_AE_key <- unique(IGW_bGW[,c("L","AE")])
        
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 4.2. Multi-trial models
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 4.2.1. XGWM07
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        #<<<< bAW_AE
        XGWM07_bAW <- predict(XGWM07.asr,
                                classify = "AWID:fAE4", 
                                only = "fa(fAE4, 1):vm(AWID, AW.giv)", 
                                pworkspace = 600000000,
                                maxit = 1)$pvals[,1:3]
        colnames(XGWM07_bAW) <- c("GID","AE","XGW_bAW")
            
        #<<<< bDW
        XGWM07_bDW <- predict(XGWM07.asr,
                                classify = "DWID", 
                                only = "vm(DWID, DW.giv)", 
                                pworkspace = 600000000,
                                maxit = 1)$pvals[,1:2]
        colnames(XGWM07_bDW) <- c("GID","XGW_bDW")
        
        #<<<< Total genetic
        XGWM07_bGW_tmp <- merge(XGWM07_bAW,XGWM07_bDW)
        XGWM07_bGW_tmp$XGW_bGW <-  XGWM07_bGW_tmp$XGW_bAW + XGWM07_bGW_tmp$XGW_bDW
        
        L_AE_key <- unique(apdata[,c("L","AE4")])
        colnames(L_AE_key)[2] <- "AE"
        
        XGWM07_bGW <- merge(XGWM07_bGW_tmp,L_AE_key)        
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 4.2.1. XQBMB1
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            
        #<<<< bAB_AE
        XQBMB1_bAB <- predict(XQBMB1.asr,
                                classify = "ABID:fAB1", 
                                only = "vm(ABID, AB.giv):fa(fAB1, 1)", 
                                pworkspace = 600000000,
                                maxit = 1)$pvals[,1:3]
        colnames(XQBMB1_bAB) <- c("GID","AE","XQB_bAB")
        
        #<<<< bAQ
        XQBMB1_bAQ_QID <- predict(XQBMB1.asr,
                                classify = "AQID", 
                                only = "vm(AQID, AQ.giv)", 
                                pworkspace = 600000000,
                                maxit = 1)$pvals[,1:2]
        colnames(XQBMB1_bAQ_QID) <- c("QID","XQB_bAQ")
        
        XQBMB1_bAQ <- merge(XQBMB1_bAQ_QID,GID_QID_key)
        
        #<<<<< bAQB
        XQBMB1_bAQB <- merge(XQBMB1_bAB,XQBMB1_bAQ)
        XQBMB1_bAQB$XQB_bAQB <- XQBMB1_bAQB$XQB_bAQ + XQBMB1_bAQB$XQB_bAB
        
        #<<<< bDB
        XQBMB1_bDB <- predict(XQBMB1.asr,
                                classify = "DBID", 
                                only = "vm(DBID, DB.giv)", 
                                pworkspace = 600000000,
                                maxit = 1)$pvals[,1:2]
        colnames(XQBMB1_bDB) <- c("GID","XQB_bDB")
        
        #<<<< Total genetic
        XQBMB1_bGQB_tmp <- merge(XQBMB1_bAQB,XQBMB1_bDB)
        XQBMB1_bGQB_tmp$XQB_bGQB <-  XQBMB1_bGQB_tmp$XQB_bAQB + XQBMB1_bGQB_tmp$XQB_bDB    
        
        XQBMB1_bGQB <- merge(XQBMB1_bGQB_tmp,L_AE_key)        

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 4.3. Cross model correlations
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 4.3.1. merge
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        IGW_XGW_XQB_bG <- merge(XQBMB1_bGQB,merge(XGWM07_bGW,IGW_bGW, all = T), all = T)
            
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # 4.3.2. Loop to estimate correlations
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        rbGWxGmod_sum_null <- NULL
        rbGWxGmod_sum <- rbGWxGmod_sum_null
        
        #<<<< Loop for each trial
        for(l in unique(IGW_XGW_XQB_bG$L))
        {
            # l = unique(IGW_XGW_XQB_bG$L)[1]
            
            #<<<< Extract for lth trial
            IGW_XGW_XQB_bG_l <- IGW_XGW_XQB_bG[IGW_XGW_XQB_bG$L ==l,]
            
            #<<<< Loop for eaxch ae within trial 
            for(ae in unique(IGW_XGW_XQB_bG_l$AE))
            {
                # ae = unique(IGW_XGW_XQB_bG_l$AE)[1]
                
                rbGWxGmod_sum_l_ae_tmp <- rbGWxGmod_sum_null
                rbGWxGmod_sum_l_ae_tmp$L <- l
                rbGWxGmod_sum_l_ae_tmp$AE <- ae
                
                rbGWxGmod_sum_l_ae <- as.data.frame(rbGWxGmod_sum_l_ae_tmp)
                
                IGW_XGW_XQB_bG_l_ae <- IGW_XGW_XQB_bG_l[IGW_XGW_XQB_bG_l$AE == ae,]
                
                rbGWxGmod_sum_l_ae$rI_W_bGW <- round(cor(IGW_XGW_XQB_bG_l_ae$IGW_bGW,
                                                            IGW_XGW_XQB_bG_l_ae$XGW_bGW,
                                                            use = 'pairwise.complete.obs'),2)
                plot(IGW_XGW_XQB_bG_l_ae$IGW_bGW,IGW_XGW_XQB_bG_l_ae$XGW_bGW)
                
                rbGWxGmod_sum_l_ae$rI_QB_bGW <- round(cor(IGW_XGW_XQB_bG_l_ae$IGW_bGW,
                                                            IGW_XGW_XQB_bG_l_ae$XQB_bGQB,
                                                            use = 'pairwise.complete.obs'),2)
                
                rbGWxGmod_sum_l_ae$rW_QB_bGW <- round(cor(IGW_XGW_XQB_bG_l_ae$XGW_bGW,
                                                            IGW_XGW_XQB_bG_l_ae$XQB_bGQB,
                                                            use = 'pairwise.complete.obs'),2)
                plot(IGW_XGW_XQB_bG_l_ae$XGW_bGW,IGW_XGW_XQB_bG_l_ae$XQB_bGQB)
                
                rbGWxGmod_sum <- rbind(rbGWxGmod_sum,rbGWxGmod_sum_l_ae)
            }
        }
    
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 6. Biplot
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.0. Call packages library
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    library(reshape2)
    library(ggfortify)
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.1. prepare data
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    #<<<<
    GID_L_list <- unique(apdata[,c("GID","L")])
    GID_L_list$BPOP <- "TAMU"
    GID_L_list$BPOP[GID_L_list$L== "K"] <- "UARK"
    GID_L_list$BPOP[GID_L_list$L== "S"] <- "CLEM"

    GID_BPOP_list <- unique(GID_L_list[,c("GID","BPOP")])

    XQBMB1_bG_merge <- merge(XQBMB1_bGQB,GID_BPOP_list)
    XQBMB1_bG_merge$bA <- XQBMB1_bG_merge$XQB_bAQB
    XQBMB1_bG_merge$bG <- XQBMB1_bG_merge$XQB_bGQB
    XQBMB1_bG_merge$bAQ <- XQBMB1_bG_merge$XQB_bAQ
    XQBMB1_bG_merge$bAB <- XQBMB1_bG_merge$XQB_bAB
    XQBMB1_bG_merge$bDB <- XQBMB1_bG_merge$XQB_bDB
    XQBMB1_bG_merge$E <- XQBMB1_bG_merge$AE

    XQBMB1_bG <- XQBMB1_bG_merge[,c("GID","BPOP","E","bG","bA","bAQ","bAB","bDB")]
    write.csv(XQBMB1_bG,"XQBMB1_bG.csv",row.names = F)

    bG_in <- XQBMB1_bG

    #<<<<< 2.1. Make  GID x E table
    
    GID_E_tab <- dcast(bG_in, GID + BPOP ~ E, value.var = "bG")
    GID_E_tab_sel <- GID_E_tab
    
    #<<<< Change the first column to rownames
    
    rownames(GID_E_tab_sel) <- GID_E_tab_sel[,1]
    GID_E_tab_sel$GIDBPOP <-  NULL

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.2. Select the data frame for PC (i.e all "E")
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    data_in_pca <- GID_E_tab_sel[3:8]
    pca_res <- prcomp(data_in_pca, scale. = T)
    
    pca_res_scaled <- pca_res
    
    Evar <- tapply(bG_in$bG,bG_in$E,FUN = var)
    
    pca_res$rotation 
    
    tpca_res_Erot <- t(pca_res$rotation)
    
    #<<<< standardise
    for(i in 1:6)
    {
    tpca_res_Erot[,i] <- tpca_res_Erot[,i]/sqrt(Evar[i])
        
    }
    
    pca_res_scaled$rotation <- t(tpca_res_Erot)
    
    pca_res_Gx <- pca_res$x
    
    for(j in 1:6)
    {
    pca_res_Gx[,j] <- pca_res_Gx[,j]/max(abs(pca_res_Gx[,j]))
    }
        
    pca_res_scaled$x <- pca_res_Gx

    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    # 6.3. Plot
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    # From CHNOTE: BPOP column (TAMU = Red open square (0), UARK = Yellow cross(4), CLEM = Blue filled circle (16)
    
    ## MFNOTE: open square shape has a black dot in the ,middle that i need to fix
    ##          will be fixed
    
    peach_biplot <- autoplot(pca_res_scaled, 
                                data = GID_E_tab_sel, 
                                group = 'BPOP', 
                                loadings=TRUE,
                               loadings.colour = 'black',
                                loadings.label = TRUE, 
                                loadings.label.size = 5, 
                                loadings.label.colour= 'black') +
        
                                geom_point(aes(shape=BPOP, color=BPOP, size=BPOP))+
                                scale_shape_manual(values=c(16, 18, 8))+ # customize shape
                                scale_color_manual(values=c('orange', 'maroon','blue'))+
                                scale_size_manual(values=c(2,3,2)) + theme_bw() +
                                theme(axis.text.x = element_text(color = "black", size = 12),
                                      axis.text.y = element_text(color = "black", size = 12),  
                                      axis.title.x = element_text(color = "black", size = 12),
                                      axis.title.y = element_text(color = "black", size = 12)) +
                                                                  theme(legend.position="top")




#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# 7. Analysis of QTL
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
#<<<< QTL effects
XQBMB1_bAQ_QID <- XQBMB1_bAQ_QID

apdata_BP <- apdata
apdata_BP$BP <- "TAMU"

apdata_BP$BP[apdata_BP$L == "K"] <- "UARK"
apdata_BP$BP[apdata_BP$L == "S"] <- "Clem"

uQBP <- unique(apdata_BP[,c("QID","BP")])

uQBP_mat <- as.matrix(table(uQBP$QID,uQBP$BP))

XQBMB1_bAQ_QID_mat <- as.matrix(XQBMB1_bAQ_QID)

uQBP_bQID <- cbind(uQBP_mat,XQBMB1_bAQ_QID[,2])

colnames(uQBP_bQID)[4] <- "bQID"

uQBP_bQID[order(-uQBP_bQID[,'bQID']),]
